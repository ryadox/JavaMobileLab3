package com.example.myapplab3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Screen2Activity extends AppCompatActivity {
    private TextView t1;
    private Button b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_screen2);

        t1 = findViewById(R.id.recap);
        b2 = findViewById(R.id.btnRetour);

        Intent it = getIntent();
        String v1 = it.getStringExtra("p1");
        String v2 = it.getStringExtra("p2");
        String v3 = it.getStringExtra("p3");
        String v4 = it.getStringExtra("p4");
        String v5 = it.getStringExtra("p5");

        String r = "Full Name: " + sf(v1) + "\n" +
                   "Email: " + sf(v2) + "\n" +
                   "Phone: " + sf(v3) + "\n" +
                   "Address: " + sf(v4) + "\n" +
                   "City: " + sf(v5);

        t1.setText(r);

        b2.setOnClickListener(v -> finish());
    }

    private String sf(String s) {
        return (s == null || s.trim().isEmpty()) ? "--" : s.trim();
    }
}

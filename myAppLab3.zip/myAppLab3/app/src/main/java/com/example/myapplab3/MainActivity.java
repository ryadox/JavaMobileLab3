package com.example.myapplab3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText f1, f2, f3, f4, f5;
    private Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        f1 = findViewById(R.id.nom);
        f2 = findViewById(R.id.email);
        f3 = findViewById(R.id.phone);
        f4 = findViewById(R.id.adresse);
        f5 = findViewById(R.id.ville);
        b1 = findViewById(R.id.btnEnvoyer);

        b1.setOnClickListener(view -> {
            String v1 = f1.getText().toString().trim();
            String v2 = f2.getText().toString().trim();
            String v3 = f3.getText().toString().trim();
            String v4 = f4.getText().toString().trim();
            String v5 = f5.getText().toString().trim();

            if (v1.isEmpty() || v2.isEmpty()) {
                Toast.makeText(this, "Empty fields!", Toast.LENGTH_SHORT).show();
            } else {
                Intent it = new Intent(this, Screen2Activity.class);
                it.putExtra("p1", v1);
                it.putExtra("p2", v2);
                it.putExtra("p3", v3);
                it.putExtra("p4", v4);
                it.putExtra("p5", v5);
                startActivity(it);
            }
        });
    }
}
